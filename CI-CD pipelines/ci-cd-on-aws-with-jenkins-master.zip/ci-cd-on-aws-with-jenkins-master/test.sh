#!/usr/bin/env sh

docker-compose build
